%%  load data
clear all;
clc;
subname={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12','S13','S14','S15'};
data=[];
for  sub=1:length(subname)
    for block=1:5
        load(['.\rawdata\OnlineData_online\',subname{sub},'\block',num2str(block),'.mat']);
        for target=1:40
            data(sub,:,:,target,block)=data_all{target}';
        end
    end
end
%% calculation
choosechannel=[1:40];
time=0.3;%data length 
Blocks=5;
Targets=40;
nfb=7;
%
addpath .\FBTRCA_decode_40
acc_trca=[];
itr_trca=[];
for sub=1:15
    disp(['----------sub:',num2str(sub),'-----------']);
    fliter_data=squeeze(data(sub,:,:,:,:));
    load(['.\online_model\trca_40\',subname{sub},'_model_3.mat']);%model
    for block=1:Blocks
        % Test
        cnt = 0;
        testdata = squeeze(fliter_data(choosechannel,:,:,block));
        for i=1:Targets
            prediction = test_FBTRCA(squeeze(testdata(:,:,i,:)),model,time);
            cnt = cnt + (i==prediction);
        end
        acc_trca(sub,block) = cnt/40;
        itr_trca(sub,block)=itr(40, squeeze(acc_trca(sub,block)),0.8);
        disp(['Block:',num2str(block),'  ACC:',num2str(acc_trca(sub,block)),'  ITR:',num2str(itr_trca(sub,block))]);
    end
end
save('.\online_40.mat','acc_trca','itr_trca');

%%  StimTime:300 ms  ��mean value and  STE value��
clear all;
clc;
subname={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12','S13','S14','S15'};
load online_40.mat
% accuracy
acc_sub=squeeze(mean(acc_trca,2))*100 % each subject mean value
acc_mean=squeeze(mean(acc_trca,[1,2]))*100 % all subject mean value
acc_neg=std(squeeze(mean(acc_trca,2))*100)/sqrt(length(subname)) % standard errors.
% ITR
itr_sub=squeeze(mean(itr_trca,2)) % each subject mean value
itr_mean=squeeze(mean(itr_trca,[1,2])) % all subject mean value
itr_neg=std(mean(itr_trca,2))/sqrt(length(subname))% standard errors.










