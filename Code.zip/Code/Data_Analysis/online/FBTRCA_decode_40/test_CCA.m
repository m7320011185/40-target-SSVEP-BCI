function result = test_CCA(data,datalength)
%TEST_CCA 此处显示有关此函数的摘要
% 实现 ccA算法
%% 实验信息
latency=140;%视觉延迟
Targets=40;%目标数
Channels=40;%通道数
freq=[8:15,8.2:15.2,8.4:15.4,8.6:15.6,8.8:15.8];
Fs=1000;
fs=Fs/4;
stimtime=datalength/Fs;
N=datalength/4;%250
t = [1:N]/fs; %1:1/250:1
nFB = 1;
    weights = [1:nFB].^(-1.25)+0.25; % fliter bank weight
%% templete
for ii = 1:length(freq)
    s1 = sin(2*pi*freq(ii)*t);
    s2 = cos(2*pi*freq(ii)*t);
    s3 = sin(2*pi*2*freq(ii)*t);
    s4 = cos(2*pi*2*freq(ii)*t);
    s5 = sin(2*pi*3*freq(ii)*t);
    s6 = cos(2*pi*3*freq(ii)*t);
    s7 = sin(2*pi*4*freq(ii)*t);
    s8 = cos(2*pi*4*freq(ii)*t);
    refData(:,:,ii) = cat(2,s1',s2',s3',s4',s5',s6',s7',s8');%250     8     4
end
% define bandpass filter
fs_fliter=fs/2;
fls1 = 5;
fls2= 3;
fhs1 = 90;
fhs2= 100;
Wp=[fls1/fs_fliter fhs1/fs_fliter];%
Ws=[fls2/fs_fliter fhs2/fs_fliter];%
[k,Wn]=cheb1ord(Wp,Ws,3,40);
[B,A] = cheby1(k,0.5,Wn);
%%
downdata=[];
%人
downdata = downsample(data(:,[1+latency:datalength+latency])',4);
%光电管
% downdata = downsample(data(:,[1:datalength])',4);
bpDatah1 = filtfilt(B,A,downdata);
testDatah1=squeeze(bpDatah1);
%CCA
for ff=1:length(freq)
    [~,~,D] = canoncorr(testDatah1, refData([1:datalength/4],1:4,ff));
    cc(1,ff)=D(1);
end
% cc_all(:,:,block,trial)=cc;
CC=weights*cc.^2;
result=find(CC==max(CC));
end

