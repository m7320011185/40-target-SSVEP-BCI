function result = test_FBTRCA(data,model,Time)
% ƥ��
Trials=40;
latency=140;
time=round(Time*1000);
nFBs=7;
weights = [1:nFBs].^(-0.5)+0;
%% FLITER
rfs = 250;
fs_fliter=rfs/2;
fls1= [6 14 22	30	38	46	54	62	70	78];
fls2= [4 10 16	24	32	40	48	56	64	72];
fhs1= [90 90 90 90 90 90 90 90 90 90];
fhs2= [100 100 100 100 100 100 100  100 100 100];
for nFB=1:nFBs
    Wp=[fls1(nFB)/fs_fliter fhs1(nFB)/fs_fliter];%
    Ws=[fls2(nFB)/fs_fliter fhs2(nFB)/fs_fliter];%
    [k,Wn]=cheb1ord(Wp,Ws,3,40);
    [B{nFB},A{nFB}] = cheby1(k,0.5,Wn);
end
% �ݲ� ������ �˲�
Xh1 =[];
for channel=1:size(data,1)
    downdata = downsample(squeeze(data(channel,:)),4);
    for nfb=1:nFBs
        Xh1(channel,:,nfb)= filtfilt(B{nfb},A{nfb},downdata);
    end
end
latencyDelay1 = 25;
latencyDelay2 = latency/4;
Xh1=Xh1(:,[1+latencyDelay1:(time/4+latencyDelay2)],:);

aver_Traindata = model.traindatah; %40 250 40(target)
wn = model.SFsAllh;%40 40(target)
cc=[];
SFsIndex=[1:Trials];
for nfb=1:nFBs
    for ff=1:Trials
        Yh1=squeeze(aver_Traindata(:,:,ff,nfb)); %40 250
        Xh2=squeeze(Xh1(:,:,nfb));
        U1 = Xh2' * [squeeze(wn(:,SFsIndex,nfb))];
        V1 = Yh1' * [squeeze(wn(:,SFsIndex,nfb))];
        cc(nfb,ff) = corr2_new(U1,V1);
    end
end

rrr =weights(1:nFBs)*(sign(cc(1:nFBs,:)).*abs(cc(1:nFBs,:)).^2);%% �жϽ��
result= find(rrr==max(rrr));
end

