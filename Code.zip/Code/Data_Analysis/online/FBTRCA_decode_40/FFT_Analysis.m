function [ fre,y,p ] = FFT_Analysis( data , fs )
%FFT_ANALYSIS Summary of this function goes here
%   Detailed explanation goes here
N = length(data);
% N = 1250;
% N = 1024;
n = 0:N-1;
t = n/fs;
x=fft(data,N);
mag = abs(x);
p=angle(x);
f = n*fs/N;
fre = f(1:N/2);
y = mag(1:N/2)*2/N;
end

