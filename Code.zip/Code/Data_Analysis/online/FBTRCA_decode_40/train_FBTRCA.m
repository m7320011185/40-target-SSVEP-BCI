function model = train_FBTRCA(data,stimTime)
latency=140;
nFBs=7;
time=round(stimTime*1000);
[Channel,~,Trial,Block]=size(data);

%% 
% define filter
rfs = 250;
fs_fliter=rfs/2;
fls1 =[6 14 22	30	38	46	54	62	70	78];
fls2= [4 10 16	24	32	40	48	56	64	72];
fhs1 = [90 90 90 90 90 90 90  90 90 90];
fhs2= [100 100 100 100 100 100 100 100 100 100];
for nFB=1:nFBs
    Wp=[fls1(nFB)/fs_fliter fhs1(nFB)/fs_fliter];%3 7
    Ws=[fls2(nFB)/fs_fliter fhs2(nFB)/fs_fliter];%1 1
    [k,Wn]=cheb1ord(Wp,Ws,3,40);
    [B{nFB},A{nFB}] = cheby1(k,0.5,Wn);
end
% �ݲ� ������ �˲�
bpdata =[];
for ii = 1:Block
    for cond = 1:Trial
        for channel =1:Channel
            downdata = downsample(squeeze(data(channel,:,cond,ii)),4);
            for nfb=1:nFBs
                bpdata(channel,:,cond,ii,nfb)= filtfilt(B{nfb},A{nfb},downdata);
            end
        end
    end
end
latencyDelay1 = 25;
latencyDelay2 = latency/4;
bpdata=bpdata(:,[1+latencyDelay1:(time/4+latencyDelay2)],:,:,:);% 40    75    40    11     7

%% �ռ��˲�
wn=[];
for nfb=1:nFBs
    trca_X_All=squeeze(bpdata(:,:,:,:,nfb));
    X1=trca_X_All(:,:);
    X1=X1-repmat(mean(X1,2),1,size(X1,2));
    Q_All=X1*X1';%40*40 Э�������
    for trial=1:Trial
        trca_X=squeeze(bpdata(:,:,trial,:,nfb));
        S=trca_S(trca_X);%���ϵ������
        [V,~]=eig(Q_All\S); %��������������ֵ
        SFsh1(:,:,trial)=V;%
    end
    wn(:,1:Trial,nfb)=SFsh1(:,1,1:Trial);% ȡ�������ֵ�Ͷ�Ӧ����������
end

model.traindatah = squeeze(mean(bpdata,4));
model.SFsAllh = wn;
end

