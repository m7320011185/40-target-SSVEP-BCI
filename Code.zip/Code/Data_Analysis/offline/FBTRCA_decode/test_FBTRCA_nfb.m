function cc = test_FBTRCA_nfb(Xh1,model,Time)
% ƥ��
Trials=40;
latency=140;
time=round(Time*1000);
nFBs=7;


latencyDelay1 = 25;
latencyDelay2 = latency/4;
Xh1=Xh1(:,[1+latencyDelay1:(time/4+latencyDelay2)],:);

aver_Traindata = model.traindatah; %40 250 40(target)
wn = model.SFsAllh;%40 40(target)
cc=[];
SFsIndex=[1:Trials];
for nfb=1:nFBs
    for ff=1:Trials
        Yh1=squeeze(aver_Traindata(:,:,ff,nfb)); %40 250
        Xh2=squeeze(Xh1(:,:,nfb));
        U1 = Xh2' * [squeeze(wn(:,SFsIndex,nfb))];
        V1 = Yh1' * [squeeze(wn(:,SFsIndex,nfb))];
        cc(nfb,ff) = corr2_new(U1,V1);
    end
end


end

