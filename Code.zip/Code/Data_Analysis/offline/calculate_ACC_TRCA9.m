                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
clear all;
clc;

%% load data
% subname={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12','S13','S14','S15'};
% data=[];
% for  sub=1:length(subname)
%     for block=1:12
%         load(['.\rawdata\OnlineData_offline\',subname{sub},'\block',num2str(block),'.mat']);
%         for target=1:40
%             data(sub,:,:,target,block)=data_all{target}';
%         end
%     end
% end

%% downsample&fliter
% fliter_data=[];
% for sub=1:length(subname)
%     fliter_data =fliterdata(squeeze(data(sub,:,:,:,:)));
%     save(['.\fliterdata\',subname{sub},'.mat'],'fliter_data');
% end

%% parameters
subname={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12','S13','S14','S15'};
choosechannel=[9 15 16 17 19 20 21 35 38];
stime=[0.1:0.1:0.5];
Blocks=12;
nfb=7;
Targets=40;

%% calculation
addpath .\FBTRCA_decode
acc_trca=[]; 
itr_trca=[];
for sub=1:length(subname)
    load(['.\fliterdata\',subname{sub},'.mat']);
    for  n_time=1:length(stime)
        acc=[];
        time=stime(n_time);
        for block=1:Blocks
            % Train
            traindata = squeeze(fliter_data(choosechannel,:,:,setdiff(1:Blocks,block),:));
            model = train_FBTRCA(traindata,time,nfb);
            % Test
            cnt = 0;
            testdata = squeeze(fliter_data(choosechannel,:,:,block,:));
            for i=1:Targets
                prediction = test_FBTRCA(squeeze(testdata(:,:,i,:)),model,time,nfb);
                cnt = cnt + (i==prediction);
            end
            acc(block) = cnt/40;
        end
        acc_trca(sub,n_time)=squeeze(mean(acc));
        itr_trca(sub,n_time)=itr( 40, squeeze(mean(acc)), time+0.5);
        disp(['Stimtime:',num2str(time),'s  ACC:',num2str(acc_trca(sub,n_time)*100),'%   ITR:',num2str(itr_trca(sub,n_time)),'bits/min']);
    end
end
save('.\offline9_time.mat','acc_trca','itr_trca');

%%  StimTime:300 ms  ��mean value and  STE value��
clear all;
clc;
subname={'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12','S13','S14','S15'};
load offline9_time.mat
% accuracy
acc_sub=squeeze(mean(acc_trca(:,3),2))*100 % each subject mean value
acc_mean=squeeze(mean(acc_trca(:,3),[1,2]))*100 % all subject mean value
acc_neg=std(squeeze(acc_trca(:,3)))*100/sqrt(length(subname)) % standard errors.
% ITR
itr_sub=squeeze(mean(itr_trca(:,3),2)) % each subject mean value
itr_mean=squeeze(mean(itr_trca(:,3),[1,2])) % all subject mean value
itr_neg=std(squeeze(itr_trca(:,3)))/sqrt(length(subname))% standard errors.




